package services

type Services struct {
	KV *KVService
}
